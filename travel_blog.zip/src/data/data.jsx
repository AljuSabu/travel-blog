export const data = [
    {
        id : 1,
        place : 'Malaysia',
        discription : 'Malaysia, a shrant and diverse munty in Southeast Asaneting pot of cultures, cuisines, and landscapes. From the bustling streets of Kuala Lumpur to the idyllic beaches of Langkawi, Malaysia offers a wealth of exciting experiences for travelers',
        date : '01/12/2023 | Saturday',
        image : 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bWFsYXlzaWF8ZW58MHx8MHx8fDA%3D'
    },
        {
        id : 2,
        place : 'Rajasthan',
        discription : 'Rajasthan the Land of Kings vibrant and colorful state in northem India. Known for its rich history stunning erstitecture, and warm hospitality, Rajesthan destination that will leave you enchanted',
        date : '05/08/2023 | Sunday',
        image : 'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8UmFqYXN0aGFufGVufDB8fDB8fHww'
    },
        {
        id : 3,
        place : 'Kashmir',
        discription : 'Kashmir a paradis on sarth it a land of treathtaking beauty, serene lakes, and majestic mountains. Wins picturesque valleys, luch green forests, and vibrant sulture, Kami is a destination that will leave you spelbound',
        date : '10/12/2023 | Wednesday',
        image : 'https://images.unsplash.com/photo-1598091383021-15ddea10925d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8S2FzaG1pcnxlbnwwfHwwfHx8MA%3D%3D'
    },
        {
        id : 4,
        place : 'Bali',
        discription : 'Bali the land of the Godt, is a tropical paradis Ingen for its stunning beaches, luh gem landscapes, and itch cultural heritage',
        date : '03/03/2023 | Tuesday',
        image : 'https://images.unsplash.com/photo-1577717903315-1691ae25ab3f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8QmFsaXxlbnwwfHwwfHx8MA%3D%3D'
    },
        {
        id : 5,
        place : 'Kazakhstan',
        discription : 'Kazakhstan, the worlds largest landlocked courty, is a vest and mysterious land of untouched beauty',
        date : '04/02/2023 | Saturday',
        image : 'https://plus.unsplash.com/premium_photo-1697730150003-26a1d469adb4?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8S2F6YWtoc3RhbnxlbnwwfHwwfHx8MA%3D%3D'
    },
        {
        id : 6,
        place : 'Vietnam',
        discription : 'Vietnam, a country of breathtaking beauty and rich hatory a destination that will captivate your ser',
        date : '04/12/2023 | Monday',
        image : 'https://images.unsplash.com/photo-1521993117367-b7f70ccd029d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fFZpZXRuYW18ZW58MHx8MHx8fDA%3D'
    },
]